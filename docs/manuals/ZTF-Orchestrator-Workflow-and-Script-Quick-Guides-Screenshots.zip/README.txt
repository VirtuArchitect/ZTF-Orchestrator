ZTF-Orchestrator Quick Guide Screenshots
117 task images, captured 20 November 2026 from source 79c3ecc.

Extract all files into one directory and open gallery.html in a browser.
Each PNG is full resolution. capture-manifest.json and SHA256SUMS record provenance and integrity.

Simulated data only. No real backend or live execution. Some required fields are intentionally incomplete; lower sections may be outside the viewport. Use the separate Quick Guides for prerequisites, approvals, execution and verification. Retired console entries have no current execution screenshot.

Address examples anonymised on 22 November 2026. Affected simulated views were recreated from the same recorded source edition using documentation-only TEST-NET addresses. Original edition labels and validation boundaries are retained.
